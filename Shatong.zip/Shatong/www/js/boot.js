
bootGame = {

	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
                game.world.setBounds(0,0,bounds,0);
                keyboard = game.input.keyboard.createCursorKeys();

                game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
                game.scale.forceLascape = true;
                game.scale.pageAlignHorizontally = true;
                game.scale.pageAlignVertically = true;
                game.state.start("preloadGame");
        },
        update: function () {
        game.scale.pageAlignVertically = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.setShowAll();
        game.scale.refresh();
    }

}
preloadGame = {
	preload:function(){
        game.load.image('bg','img/sky.png');
        game.load.image('bg2','img/skyy.png');
		//game.load.image('play','img/play.png');
		game.load.image('fire','img/fire.png');
		game.load.image('platform','img/platform.png');
		game.load.spritesheet('player','img/player.png',125,138);
    	game.load.spritesheet('tsato', 'img/tsato.png',50,50);
    	game.load.spritesheet('ai', 'img/ai.png',133,138);
        game.load.image('gameover', 'img/overgame.jpg');
        game.load.image('line', 'img/line.png');
        game.load.image('ins','img/instruction.png');
        game.load.image('abawt','img/aboutbtn.png');
        game.load.image('intruc',"img/instruc.png");
    // ito yung mga music mag download kna lng ng music at palitan mu yung anjan
        game.load.audio('bgMusic', 'audio/clapping.mp3');
        game.load.audio('yay', 'audio/clapping.mp3');
        game.load.audio('boo', 'audio/clapping.mp3');
        game.load.spritesheet("start","img/startbut.png",263,117);
        game.load.spritesheet("menu2","img/menu2.png",95,94);
        game.load.image('about2','img/about2.png');

	},

	create:function(){
        game.state.start("menuGame");
	}

}

menuGame = {

	create:function(){
            game.add.sprite(0,0, "bg");

        pbtn = game.add.button(290,390,"start",this.lundag);
        pbtn.anchor.set(0.5);
        pbtn.scale.set(0.5);  

          tungkol = game.add.button(290,469,"abawt",this.tng);
                tungkol.anchor.set(0.5);

        la = game.add.button(290,542,"intruc",this.lala);
         la.anchor.set(0.5);
        la.scale.set(0.9);  
    },

lundag:function (){
        game.state.start("playGame");
   



   },

    tng: function(){
            about=game.add.image(0,0,"about2");
            about.scale.set(1.0);

            // restartButton=game.add.button(392,550,"gameover",restartB,this);
            // restartButton.scale.set(0.5);

            //  function restartB() {
            // about.visible =! restartButton.visible;
            // restartButton.destroy();
            restartButton=game.add.button(100,35,"menu2",restartB,this);
            function restartB() {
            //aboutpage.visible =! restartButton.visible;
            restartButton.destroy();

            // window.location.href=window.location.href;
            game.state.start("menuGame");
            }

            },
    lala: function(){
            about=game.add.image(0,0,"ins");
            about.scale.set(1.0);


            restartButton=game.add.button(100,50,"menu2",restartB,this);
            function restartB() {
            restartButton.destroy();

            game.state.start("menuGame");
            }

            },

}

playGame = {
	create:function(){
		console.log("current state: play");
		  game.physics.startSystem(Phaser.Physics.ARCADE);
        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.forcePortrait = false;
        game.scale.forceLandscape = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;;
        game.scale.setScreenSize = true;
        keyboard = game.input.keyboard.createCursorKeys();
        btnfire = game.add.button(0,0,'fire',tsatoGame.pushRight);

		game.add.image(0,0,'bg2');
		platform = game.add.sprite(0,0,'platform');
		platform.scale.y=2;

		line = game.add.sprite(550,200,'line');
    game.physics.arcade.enable(line);
    line.body.immovable=true;
    game.physics.arcade.enable(platform);
    platform.body.immovable=true;
    
		ai = game.add.sprite(100,50,'ai');
		 //ai2 = game.add.sprite(150,200,'ai2');
		player = game.add.sprite(700,200,'player');
		// player.scale.x=2;
    
		player.animations.add('player',[3,2,1,0,4,3],24,false);
		ai.animations.add('ai',[2,0,1],10,true);


    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;
    game.physics.arcade.enable(ai);
    ai.body.collideWorldBounds = true;
    ai.body.velocity.y=-550;
    ai.body.bounce.y=1;

		    tsatoGame.createTsatos(4572);
		    tsato = game.add.group();
		    tsato.enableBody = true;
		    tsatoGame.createTsato1s(3172);
		    tsato1 = game.add.group();
		    tsato1.enableBody = true;

    life = game.add.text(50,10,'Life: 3',{fill:"black"});
    score = game.add.text(650,10,'Score: 0',{fill:"black"});
    bestScore = game.add.text(600,40,'High Score: '+tsatoGame.retrieveBest(),{fill:"black"});
    //buttonPlay = game.add.button(0,0,'play',tsatoGame.play);;


		    // dito na magplaplay yung bg music pero yung iba sa player.kill() nakalagay
		    yaymusic = game.add.audio('yay');
		    boomusic = game.add.audio('boo');
		    bgmusic = game.add.audio('bgMusic');
		    bgmusic.play();
		    tsatoGame.loopAudio(4000);
	},

    
    update:function(){
		game.physics.arcade.collide(player,tsato);
		game.physics.arcade.overlap(player,line, tsatoGame.balikPosition);
   // game.physics.arcade.overlap(ai2,tsato,tsatoGame.killTsato2);

    game.physics.arcade.overlap(platform,tsato,tsatoGame.scoreTsato);
    game.physics.arcade.overlap(ai,tsato,tsatoGame.killTsato);

   // game.physics.arcade.overlap(ai2,tsato1,tsatoGame.killTsato12);

    game.physics.arcade.overlap(platform,tsato1,tsatoGame.scoreTsato1);
    game.physics.arcade.overlap(ai,tsato1,tsatoGame.killTsato1);

		    if(keyboard.right.isDown){
		    player1.body.velocity.x=270
		}
		else{
			ai.animations.play('ai')
		}
	}
        };
//game.state.add('Play', BasicGame, true);
//}
        var tsatoGame = function(){
    "use strict";
    return {  
          createTsatos:function(time){
            setInterval(function(){
                 tsatos = tsato.create(580,0,"tsato");
                 tsatos.animations.add('play',[0,1,2,3,4],50, true);
                tsatos.body.velocity.y=200;
                tsatos.animations.play('play');
            },time)
        },
        createTsato1s:function(time){
            setInterval(function(){
                 tsato1s = tsato.create(580,700,"tsato");
                 tsato1s.animations.add('play',[0,1,2,3,4],50, true);
                tsato1s.body.velocity.y=-370;
                tsato1s.animations.play('play');
            },time)
        },
        play:function(){
            buttonPlay.destroy();
        },
        // dito yung function para mag loop yung bgmusic
        loopAudio:function(time){
            setInterval (function (){
                bgmusic.play();
            },time);
        },
         pushRight:function(){

            player.animations.play('player');
                player.body.velocity.x=-2750;

            // dito magsstop yung music.
            // boomusic.stop();
            // yaymusic.stop();
        },
         scoreTsato:function(platform,tsatos){
                tsatos.kill();
                a = a + 1;
                score.text='Score :'+a;

                // dito magplaplay yung effect pag naka score
                yaymusic.play();
                if(a==5){
 
    ai.body.velocity.y=550;

                }
                else if(a==10){

    ai.body.velocity.y=800;
                }
                else if(a==15){

    ai.body.velocity.y=900;
  
                }
        },
         killTsato:function(ai,tsatos){
                tsatos.kill();
                b = b - 1;
                life.text='Life :'+b;
                
                // dito mag plaplay pag minus life
                boomusic.play();
                if(b==0){
                    player.kill();
                    btnfire.destroy();
                    tsatos.destroy();

        ai.animations.stop();
    ai.body.velocity.y=0;
    ai.body.bounce.y=0;

                    goButton = game.add.button(0,0,'gameover',tsatoGame.overgame);
                    if(tsatoGame.retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
            },
             killTsato2:function(ai,tsatos){
                tsatos.kill();
                ai.animations.stop();
                b = b - 1;
                life.text='Life :'+b;
                // dito mag plaplay pag minus life
                boomusic.play();
                if(b==0){
                    player.kill();
                    btnfire.destroy();
                    tsatos.destroy();
                    ai.animations.stop();
    ai.body.velocity.y=0;
    ai.body.bounce.y=0;
        

                    goButton = game.add.button(0,0,'gameover',tsatoGame.overgame);
                    if(tsatoGame.retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
        },

        scoreTsato1:function(platform,tsato1s){
                tsato1s.kill();
                ai.animations.stop();
                a = a + 1;
                score.text='Score :'+a;

                // dito magplaplay yung effect pag naka score
                yaymusic.play();
                if(a==5){

    ai.body.velocity.y=450;
   
                }
                else if(a==10){

    ai.body.velocity.y=800;
    
                }
                else if(a==15){

    ai.body.velocity.y=900;
    
                }
        },
         killTsato1:function(ai,tsato1s){
                tsato1s.kill();
                ai.animations.stop();
                b = b - 1;
                life.text='Life :'+b;
                
                // dito mag plaplay pag minus life
                boomusic.play();
                if(b==0){
                    ai.animations.stop();
                    player.kill();
                    btnfire.destroy();
                    tsatos.destroy();


    ai.body.velocity.y=0;
    ai.body.bounce.y=0;

                    goButton = game.add.button(0,0,'gameover',tsatoGame.overgame);
                    if(tsatoGame.retrieveBest() <= a){
                   localStorage.setItem("gameStorage",a);
               }
                }
            },
                     retrieveBest:function(){
            return ((localStorage.getItem("gameStorage") != null) || (localStorage.getItem("gameStorage") != ""))?localStorage.getItem("gameStorage"):0;
        },

         overgame:function(){
            window.location.href=window.location.href;
        },
    balikPosition:function(){
        player.reset(700,200);
    }

    }
    }();




	
winGame = {
	preload:function(){

	},

	create:function(){

	},

	update:function(){

	}
}

loseGame = {
	preload:function(){

	},

	create:function(){

	},

	update:function(){

	}
}